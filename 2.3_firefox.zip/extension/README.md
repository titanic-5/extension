# Torn Exchange Browser Extension

This is a browser extension to help traders that have a price list on [Torn Exchange](https://www.tornexchange.com/).

Chrome Webstore: [https://chromewebstore.google.com/detail/torn-exchange/iggcinpeofcbplffobefiojjgfeoblll](https://chromewebstore.google.com/detail/torn-exchange/iggcinpeofcbplffobefiojjgfeoblll)

Firefox Add-on:
[https://addons.mozilla.org/en-GB/firefox/addon/torn-exchange-2-0/](https://addons.mozilla.org/en-GB/firefox/addon/torn-exchange-2-0/)
